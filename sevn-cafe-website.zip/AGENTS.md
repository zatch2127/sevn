<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Application architecture
- Use TanStack leaf routes for each SEVN page and a shared SiteShell for navigation and footer, so every page is directly shareable.
- Keep uploaded business content in src/data/sevn.json and browser-safe presentation in src/components/sevn; this preserves content independently of layout changes.
- Booking and partnership forms prepare email requests rather than simulate confirmed submissions; no reservation service is connected.
- Keep the editorial menu in its own presentation module and map each product explicitly to its supporting image; label generated imagery as illustrative rather than actual product photography.
- Keep homepage panel motion in a browser-only effect hook with cancellable animations and timers, so navigation and reduced motion cannot leave overlays blocking the page.
- Keep the homepage hero sticky within an isolated homepage wrapper and place opaque following sections above it, so scrolling reveals content over the image without leaking the pinned hero into other pages; disable pinning for reduced motion.
