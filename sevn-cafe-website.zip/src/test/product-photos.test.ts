import { describe, expect, it } from 'vitest';
import data from '../data/sevn.json';
import { itemPhotos } from '../components/sevn/product-photos';

describe('menu product image coverage', () => {
  it('provides a supporting image for all 25 supplied products', () => {
    const products = data.menu.flatMap(category => category.items);
    expect(products).toHaveLength(25);
    for (const product of products) {
      expect(itemPhotos[product.n]?.src, product.n).toBeTruthy();
    }
  });
});